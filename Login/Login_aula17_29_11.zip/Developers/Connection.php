<?php
$pdo = new PDO ("mysql: host= localhost; dbname=login_smallcontrol", "root" , "");
$pdo -> exec("SET NAMES utf8");
?>