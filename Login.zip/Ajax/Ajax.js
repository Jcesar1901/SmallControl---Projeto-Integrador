$(document).ready(function() {
    //Login
	
	//Logout
	
	//Active Login Direct
	
	//Recuperação de Senha
	
	//Nova Senha
	
});
