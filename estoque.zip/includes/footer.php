<footer class="bgcolor text-center noPrint">
	<section class="textfooter">
		<h3 class="font-text-light-extra font-weight-heavy color-white"><?= $titleSite ?> - &copy; <?= date('Y') ?> Todos os direitos reservados.</h3>
		<p class="font-text-light font-weight-heavy color-white">Sistema desenvolvido por: <?= $nameAuthorSite ?></p>
	</section>
</footer>
